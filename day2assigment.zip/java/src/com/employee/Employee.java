package com.employee;

public class Employee {
    public String name=new String();
    public int age;
    public String city=new String();
    public void show() {
        System.out.println("The name is "+name+" his age is "+age+" and his city is "+city);
    }
}
