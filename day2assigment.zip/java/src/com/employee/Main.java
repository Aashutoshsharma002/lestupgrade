package com.employee;

public class Main {

    public static void main(String[] args) {
	Employee E1=new Employee();
	E1.name="raj";
	E1.age=20;
	E1.city="Sikar";
	E1.show();
	Employee E2=new Employee();
	E2.name="Kundan";
	E2.age=22;
	E2.city="jaipur";
	E2.show();
    }
}
