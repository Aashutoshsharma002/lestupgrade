package com.employee;

public class Main {

    public static void main(String[] args) {
    prentclass pc=new prentclass();
    pc.getDetails();
    pc.DisplayDetails();
    }
}
