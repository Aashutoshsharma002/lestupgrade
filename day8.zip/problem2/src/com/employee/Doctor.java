package com.employee;

public class Doctor extends prentclass {
    public void DocDetail()
    {
        String y="Doctor "+DisplayDetails();
        System.out.println(y);
    }
}
