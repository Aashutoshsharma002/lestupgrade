package com.employee;

public class Engineer extends prentclass {
    public void engDetails()
    {
        String y="Mr Engineer "+DisplayDetails();
        System.out.println(y);
    }
}
