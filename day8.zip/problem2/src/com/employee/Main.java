package com.employee;

public class Main {

    public static void main(String[] args) {
	    Doctor D=new Doctor();
	    D.getDetails();
	    D.DocDetail();
	    Engineer E=new Engineer();
	    E.getDetails();
	    E.engDetails();
	    pilots p=new pilots();
	    p.getDetails();
	    p.pilDetails();
    }
}
