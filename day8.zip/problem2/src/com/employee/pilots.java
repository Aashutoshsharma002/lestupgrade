package com.employee;

public class pilots extends prentclass {
    public void pilDetails()
    {
        System.out.println("Mr pilote"+DisplayDetails());
    }
}
